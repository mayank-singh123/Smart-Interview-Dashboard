import subprocess
import uuid
import os
import shutil
from pathlib import Path
import platform

BASE_DIR = Path(__file__).resolve().parent / "temp_code"
BASE_DIR.mkdir(parents=True, exist_ok=True)

IS_WINDOWS = platform.system() == "Windows"

LANG_CONFIG = {
    "python": {
        "extension": "py",
        "command": lambda filename: ["python", filename] if IS_WINDOWS else ["python3", filename]
    },
    "cpp": {
        "extension": "cpp",
        "command": lambda filename: [
            "cmd", "/c", f"g++ {filename} -o {filename}.exe && {filename}.exe"
        ] if IS_WINDOWS else [
            "sh", "-c", f"g++ {filename} -o {filename}.out && {filename}.out"
        ]
    },
    "javascript": {
        "extension": "js",
        "command": lambda filename: ["node", filename]
    },
    "java": {
        "extension": "java",
        "command": lambda filename: [
            "cmd", "/c", f"javac {filename} && java -cp {Path(filename).parent} Main"
        ] if IS_WINDOWS else [
            "sh", "-c", f"javac {filename} && java -cp {Path(filename).parent} Main"
        ]
    },
}

def execute_user_code(language, code, input):
    if language not in LANG_CONFIG:
        return {"error": f"Unsupported language: {language}"}

    config = LANG_CONFIG[language]
    session_id = str(uuid.uuid4())
    temp_dir = BASE_DIR / session_id
    temp_dir.mkdir(parents=True, exist_ok=True)

    file_name = "Main" if language == "java" else "main"
    file_path = temp_dir / f"{file_name}.{config['extension']}"

    # file_path = temp_dir / f"main.{config['extension']}"

    with open(file_path, "w") as f:
        f.write(code)

    try:
        print("input = ", input, ";")
        result = subprocess.run(
            config["command"](str(file_path)),
            input=input,
            capture_output=True,
            text=True,
            timeout=5  # prevent infinite loops
        )

        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "exit_code": result.returncode
        }

    except subprocess.TimeoutExpired:
        return {"error": "Code execution timed out"}
    except Exception as e:
        return {"error": f"Execution error: {str(e)}"}
    finally:
        # Cleanup
        shutil.rmtree(temp_dir, ignore_errors=True)
