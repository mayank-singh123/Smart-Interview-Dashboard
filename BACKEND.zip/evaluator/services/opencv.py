import cv2
import sys
import json
import numpy as np


def start_monitoring(candidate_id):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam")
        return

    classifier = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_alt2.xml')

    try:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture frame")
            return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = classifier.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        # print(faces)

        a = np.array(faces)
        if a.size != 0:
            faces_list = faces.tolist()
            print(json.dumps({"candidate_id": candidate_id, "faces": faces_list}))
        else:
            print(json.dumps({"candidate_id": candidate_id, "faces": []}))

    except KeyboardInterrupt:
        print("Monitoring stopped by user")
    finally:
        cap.release()
        cv2.destroyAllWindows()

def main():
    if len(sys.argv) < 2:
        print("Candidate ID not provided")
        sys.exit(1)
    candidate_id = sys.argv[1]
    start_monitoring(candidate_id)

if __name__ == "__main__":
    main()
