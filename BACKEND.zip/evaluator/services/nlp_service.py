from sentence_transformers import SentenceTransformer, util
import nltk
from nltk.corpus import stopwords
import re

# Only required once
nltk.download('punkt')
nltk.download('stopwords')

model = SentenceTransformer('all-MiniLM-L6-v2')
stop_words = set(stopwords.words('english'))

def preprocess(text):
    text = re.sub(r'[^\w\s]', '', text.lower())
    tokens = nltk.word_tokenize(text)
    return [word for word in tokens if word not in stop_words]

def completeness_score(actual, expected):
    actual_tokens = set(preprocess(actual))
    expected_tokens = set(preprocess(expected))
    if not expected_tokens:
        return 100.0
    covered = actual_tokens.intersection(expected_tokens)
    return (len(covered) / len(expected_tokens)) * 100

def semantic_similarity_score(actual, expected):
    embeddings = model.encode([actual, expected], convert_to_tensor=True)
    similarity = util.pytorch_cos_sim(embeddings[0], embeddings[1])
    return float(similarity[0][0].item()) * 100

def evaluate_answer_nlp(actual: str, expected: str) -> dict:
    if not actual.strip() or not expected.strip():
        return {
            "correctness_score": 0.0,
            "completeness_score": 0.0,
            "final_score": 0.0
        }

    try:
        completeness = completeness_score(actual, expected)
        similarity = semantic_similarity_score(actual, expected)

        final_score = round((similarity * 0.6 + completeness * 0.4), 2)

        return {
            "correctness_score": round(similarity, 2),
            "completeness_score": round(completeness, 2),
            "final_score": final_score
        }

    except Exception as e:
        print(f"NLP Evaluation error: {e}")
        return {
            "correctness_score": 0.0,
            "completeness_score": 0.0,
            "final_score": 0.0,
            "error": str(e)
        }

