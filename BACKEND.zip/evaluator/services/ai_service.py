import cohere
from django.conf import settings
from faster_whisper import WhisperModel

co = cohere.ClientV2(settings.COHERE_API_KEY)

def generate_mcq_questions(technology, difficulty="medium", num_questions=20):
    prompt = f"""
Generate {num_questions} multiple-choice questions on {technology} for a {difficulty} difficulty level.
Each question should include:
- The question text
- 4 options labeled A to D
- The correct answer (A, B, C, or D)

Format:
1. Question text?
A. Option A
B. Option B
C. Option C
D. Option D
Answer: B
"""
    response = co.chat(
        model="command-r-03-2024",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.message.content[0].text if response.message else None

def generate_coding_question(topic, difficulty="medium", language="python"):
    prompt = f"""
    Generate a coding question in {language} on the topic of '{topic}' with a difficulty level of '{difficulty}'.
    Include:
    - Problem description
    - Input format
    - Output format
    - Constraints
    """
    response = co.chat(
        model="command-r-03-2024",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.message.content[0].text if response.message else None

def generate_feedback(evaluation_text):
    prompt = f"Generate constructive feedback for a student based on the following code evaluation: '{evaluation_text}' Focus on explaining errors and suggesting improvements."
    response = co.chat(
        model="command-r-03-2024",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.message.content[0].text if response.message else None

def transcribe_audio(wav_path: str) -> str:
    model = WhisperModel("base", compute_type="int8")
    segments, _ = model.transcribe(wav_path)
    transcript = " ".join([segment.text for segment in segments])
    return transcript

# def evaluate_audio_answer(question: str, answer_text: str) -> str:
    prompt = f"""
    You are an AI interviewer. Evaluate the following answer to the question.

    Question: {question}
    Answer: {answer_text}

    Provide a short, constructive evaluation. Mention if the answer is correct and why.
    """
    response = co.chat(
        model="command-r-03-2024",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.message.content[0].text if response.message else "No feedback generated."

from .nlp_service import evaluate_answer_nlp
from django.http import JsonResponse

def evaluate_audio_response(question: str, audio_file_path: str) -> dict:
    try:
        answer_text = transcribe_audio(audio_file_path)
    except Exception as e:
        return {"error": f"Transcription failed: {str(e)}"}

    try:
        ideal_response = co.chat(
            model="command-r-03-2024",
            messages=[{
                "role": "user",
                "content": f"Give a concise, correct answer to this interview question: {question}"
            }]
        ).message.content[0].text.strip()
    except Exception as e:
        return {"error": f"Cohere generation failed: {str(e)}"}

    try:
        print(ideal_response)

        nlp_result = evaluate_answer_nlp(answer_text, ideal_response)
        return {
            "question": question,
            "transcription": answer_text,
            "expected_answer": ideal_response,
            "correctness_score": nlp_result["correctness_score"],
            "completeness_score": nlp_result["completeness_score"],
            "score": nlp_result["final_score"]
        }

    except Exception as e:
        # logger.error(f"NLP scoring failed: {e}")
        return JsonResponse({
            "error": "Evaluation failed due to NLP scoring error.",
            "details": str(e)
        }, status=500)
