def start_monitoring(candidate_id):
    print(f"Monitoring started for {candidate_id}")

def stop_monitoring(candidate_id):
    print(f"Monitoring stopped for {candidate_id}")
