import json
from jsonschema import validate, ValidationError
from celery import shared_task
import cohere
from django.conf import settings
import textwrap

# Initialize Cohere client once
co = cohere.Client(settings.COHERE_API_KEY)

def create_flexible_prompt(compressed_question: str, language: str, schema: dict) -> str:
    schema_json = json.dumps(schema, indent=2)
    prompt = f"""
    You are an expert AI generating test cases for software problems.

    Problem Description:
    \"\"\"{compressed_question}\"\"\"
    Language: {language}

    Your output MUST be valid JSON conforming exactly to this schema:
    {schema_json}

    Rules:
    - Do not include any explanation, comments, or markdown.
    - Only output the JSON matching the schema.
    """
    return textwrap.dedent(prompt).strip()

def validate_output(output_str: str, schema: dict):
    try:
        parsed = json.loads(output_str)
        validate(instance=parsed, schema=schema)
        return parsed
    except (json.JSONDecodeError, ValidationError) as e:
        raise ValueError(f"Validation failed: {str(e)}")

def enforce_output_format(prompt: str, schema: dict, max_retries: int = 3):
    for attempt in range(max_retries):
        response = co.generate(
            model="command-r-03-2024",  # Use your supported model name here
            prompt=prompt,
            max_tokens=600,
            temperature=0.3,
        ).generations[0].text.strip()

        # Clean markdown fences if present
        if response.startswith("```"):
            response = response.strip("```").split("\n", 1)[-1].strip()

        try:
            return validate_output(response, schema)
        except ValueError:
            prompt += "\n\n⚠️ Reminder: output ONLY valid JSON matching the schema, no explanations."
    raise ValueError("Failed to get valid structured output after retries.")

@shared_task
def process_test_case_generation(compressed_question: str, language: str, schema: dict):
    prompt = create_flexible_prompt(compressed_question, language, schema)
    test_cases = enforce_output_format(prompt, schema)
    return test_cases


# Example default schemas you can import from here:

ARRAY_OF_TEST_CASES_SCHEMA = {
  "type": "array",
  "items": {
    "type": "object",
    "required": ["input", "output"],
    "properties": {
      "input": {"type": ["string", "object", "array", "null"]},
      "output": {"type": ["string", "object", "array", "null"]}
    }
  }
}

SINGLE_TEST_CASE_SCHEMA = {
  "type": "object",
  "required": ["input", "output"],
  "properties": {
    "input": {"type": ["string", "object", "array", "null"]},
    "output": {"type": ["string", "object", "array", "null"]}
  }
}

ANY_JSON_SCHEMA = {}  # Accept anything valid JSON
