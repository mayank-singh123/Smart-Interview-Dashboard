from django.urls import path
from .views import interview_views, code_views, mcq_views, monitor_views
from .views.registration_views import RegisterView, CustomTokenObtainPairView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', CustomTokenObtainPairView.as_view(), name='login'),

    path('question/', code_views.get_question_for_round),
    path('run-code/', code_views.run_code),
    path('test-cases/', code_views.generate_test_cases_view),
    path('evaluate-code/', code_views.evaluate_code),

    path('mcq/', mcq_views.mcq_questions),

    path('ai-interview/question/', interview_views.get_ai_interview_question),
    path('ai-interview/evaluate/', interview_views.evaluate_audio),

    path('detect-face/', monitor_views.detect_face),
    path('submit-audio/', monitor_views.submit_audio),
    path('upload-screen/', monitor_views.upload_screen),
    path('start-interview/', monitor_views.start_interview),   
]