from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('interviewer', 'Interviewer'),
        ('candidate', 'Candidate'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)

class Candidate(models.Model):
    PROGRESS_CHOICES = [
        ('Started', 'Started'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed')
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    skill_set = models.CharField(max_length=100)
    progress = models.CharField(max_length=20, choices=PROGRESS_CHOICES, default='Started')
    interview_start_time = models.DateTimeField(null=True, blank=True)
    interview_end_time = models.DateTimeField(null=True, blank=True)
    coding_submission = models.TextField(blank=True, null=True)

class Interview(models.Model):
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    skill_set = models.CharField(max_length=100)
    interview_start_time = models.DateTimeField()
    interview_end_time = models.DateTimeField(null=True, blank=True)

class InterviewRound(models.Model):
    interview = models.ForeignKey(Interview, related_name='rounds', on_delete=models.CASCADE)
    round_number = models.IntegerField()
    question = models.TextField()
    answer = models.TextField(null=True, blank=True)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)


class Question(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    language = models.CharField(max_length=50)
    input = models.TextField()
    expected_output = models.TextField()

class MCQQuestion(models.Model):
    question = models.TextField()
    option_a = models.CharField(max_length=255)
    option_b = models.CharField(max_length=255)
    option_c = models.CharField(max_length=255)
    option_d = models.CharField(max_length=255)
    correct_answer = models.CharField(max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')])
    technology = models.CharField(max_length=100)
    difficulty = models.CharField(max_length=10)

    def to_dict(self):
        return {
            "id": self.id,
            "question": self.question,
            "options": {
                "A": self.option_a,
                "B": self.option_b,
                "C": self.option_c,
                "D": self.option_d,
            },
            "correctAnswer": self.correct_answer,
        }
