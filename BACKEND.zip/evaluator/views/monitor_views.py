

from rest_framework.decorators import api_view, parser_classes
from rest_framework.response import Response
from rest_framework import status
from evaluator.models import Candidate, Interview
from rest_framework.parsers import MultiPartParser

import datetime
import cv2
import numpy as np

@api_view(['POST'])
@parser_classes([MultiPartParser])
def detect_face(request):
    try:
        image_file = request.FILES.get('image')
        if not image_file:
            return Response({"error": "No image provided"}, status=status.HTTP_400_BAD_REQUEST)

        # Read image as a NumPy array
        npimg = np.frombuffer(image_file.read(), np.uint8)
        img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)

        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Load Haar cascade for face detection
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )

        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)

        results = [{'x': int(x), 'y': int(y), 'w': int(w), 'h': int(h)} for (x, y, w, h) in faces]

        return Response({"faces": results})

    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@parser_classes([MultiPartParser])
def submit_audio(request):
    try:
        audio_file = request.FILES.get('audio')
        if not audio_file:
            return Response({"error": "No audio file provided"}, status=status.HTTP_400_BAD_REQUEST)

        with open('received_audio.webm', 'wb') as f:
            for chunk in audio_file.chunks():
                f.write(chunk)

        return Response({"message": "Audio received successfully."})

    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['POST'])
@parser_classes([MultiPartParser])
def upload_screen(request):
    try:
        screen_file = request.FILES.get('screen')
        if not screen_file:
            return Response({"error": "No screen video provided"}, status=status.HTTP_400_BAD_REQUEST)

        # Save it to disk
        with open('screen_recording.webm', 'wb') as f:
            for chunk in screen_file.chunks():
                f.write(chunk)

        return Response({"message": "Screen recording received."})

    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['POST'])
def start_interview(request):
    candidate_id = request.data.get("candidateId")
    try:
        candidate = Candidate.objects.get(pk=candidate_id)
        interview = Interview.objects.create(candidate=candidate, skill_set=candidate.skill_set,
                                             interview_start_time=datetime.datetime.now())
        return Response({"message": "Interview started", "interview_id": interview.id})
    except Candidate.DoesNotExist:
        return Response({"error": "Candidate not found"}, status=status.HTTP_404_NOT_FOUND)
