
import json
from rest_framework.decorators import api_view
from rest_framework.response import Response

from evaluator.services import ai_service, agentic_ai, code_runner
from evaluator.services.agentic_ai import ANY_JSON_SCHEMA

from django.http import JsonResponse

from transformers import pipeline

compressor = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")

@api_view(['POST'])
def generate_test_cases_view(request):
    try:
        data = json.loads(request.body)
        question = data.get('question', '')
        language = data.get('language', 'python')

        if not question:
            return JsonResponse({'error': 'Question is required'}, status=400)

        # Compress the question
        compressed = compressor(question, max_length=60, min_length=20, do_sample=False)[0]['summary_text']

        # Generate test cases
        test_cases = agentic_ai.process_test_case_generation(compressed, language, ANY_JSON_SCHEMA)
        # test_cases = ai_service.generate_test_cases(compressed, language)

        return JsonResponse({'compressed_question': compressed, 'test_cases': test_cases}, status=200)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
    

@api_view(['POST'])
def run_code(request):
    try:
        code = request.data.get('code')
        language = request.data.get('language')
        user_input = request.data.get("input")
        print(language, code, user_input)
        
        if language not in ['python', 'javascript', 'cpp', 'java']:
            return Response({'error': 'Unsupported language'}, status=400)

        output = code_runner.execute_user_code(language, code, user_input)
        print(output)
        return Response({"output": output})

    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(['POST'])
def evaluate_code(request):
    try:
        question = request.data.get('question')
        code = request.data.get('code')
        language = request.data.get('language')
        test_cases = request.data.get('test_cases')

        if language not in ['python', 'javascript', 'cpp', 'java']:
            return Response({'error': 'Unsupported language'}, status=400)

        evaluation = ai_service.evaluate_code(question, code, language, test_cases)
        if evaluation:
            feedback = ai_service.generate_feedback(evaluation)
            if feedback:
                print(feedback)

        return Response({"aiEvaluation": feedback})

    except Exception as e:
        return Response({"error": str(e)}, status=500)
    
@api_view(['GET'])
def get_question_for_round(request):
    topic = request.GET.get('topic', 'object mainupulation')
    difficulty = request.GET.get('difficulty', 'medium')
    language = request.GET.get('language', 'javascript')
    
  
    round_type = request.query_params.get("type", "coding")

    if round_type == "technical":
        question = ai_service.generate_coding_question(topic, difficulty, language)
    elif round_type == "behavioral":
        question = "Describe a time you overcame a workplace challenge."
    else:
        question = "Write a function to reverse a string."

    return Response({"question": question})
