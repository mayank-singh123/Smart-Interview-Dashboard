
from rest_framework.decorators import api_view, parser_classes
from rest_framework.response import Response

from rest_framework import status
from evaluator.services import ai_service

import cohere
import tempfile
import os
from django.conf import settings
from rest_framework.parsers import MultiPartParser

@api_view(['GET'])
def get_ai_interview_question(request):
    try:
        co = cohere.Client(settings.COHERE_API_KEY)
        prompt = (
            "Generate a concise, single-line technical interview question for a software developer based on a different fundamental concept in Java (e.g., OOP, data types, control flow, exception handling, collections, multithreading, etc.)."
        )
        response = co.generate(
            model='command-r-plus',
            prompt=prompt,
            max_tokens=100,
            temperature=0.7
        )
        full_text = response.generations[0].text.strip()

        if ":" in full_text:
            question = full_text.split(":", 1)[-1].strip()
        else:
            question = full_text

        return Response({"question": question})
    except Exception as e:
        print("Error in get_ai_interview_question:", str(e))
        return Response({"error": str(e)}, status=500)
 
@api_view(['POST'])
@parser_classes([MultiPartParser])
def evaluate_audio(request):
    if 'audio' not in request.FILES or 'question' not in request.data:
        return Response({'error': 'Audio file and question are required'}, status=status.HTTP_400_BAD_REQUEST)

    question = request.data['question']
    audio_file = request.FILES['audio']

    try:
        with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as tmp_audio:
            for chunk in audio_file.chunks():
                tmp_audio.write(chunk)
            tmp_audio.flush()
            tmp_audio_path = tmp_audio.name
    except Exception as e:
        return Response({'error': f"File handling failed: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    result = ai_service.evaluate_audio_response(question, tmp_audio_path)

    if os.path.exists(tmp_audio_path):
        os.remove(tmp_audio_path)

    if "error" in result:
        return Response(result, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return Response(result, status=status.HTTP_200_OK)