from rest_framework.decorators import api_view
from rest_framework.response import Response

from evaluator.services import ai_service

@api_view(['GET'])
def mcq_questions(request):
    tech = request.GET.get('technology', 'javascript')
    level = request.GET.get('difficulty', 'medium')

    try:
        result = ai_service.generate_mcq_questions(tech, level, 20)

        # Parse the raw response into structured JSON
        mcqs = []
        for block in result.strip().split('\n\n'):
            lines = block.strip().split('\n')
            if len(lines) >= 6:
                question = lines[0].split('. ', 1)[-1].strip()
                options = {
                    "A": lines[1][2:].strip(),
                    "B": lines[2][2:].strip(),
                    "C": lines[3][2:].strip(),
                    "D": lines[4][2:].strip(),
                }
                answer = lines[5].split(':')[-1].strip()
                mcqs.append({
                    "question": question,
                    "options": options,
                    "correct_answer": answer
                })

        return Response(mcqs)

    except Exception as e:
        return Response({"error": str(e)}, status=500)
