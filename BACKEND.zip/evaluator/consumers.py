import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import AnonymousUser

class InterviewConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f"interview_{self.room_name}"
        user = self.scope['user']

        # Check authentication
        if user is None or isinstance(user, AnonymousUser):
            await self.close()
            return

        # Authorize only the candidate and interviewer of this room
        if not await self.is_user_allowed(user, self.room_name):
            await self.close()
            return

        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                "type": "chat_message",
                "message": text_data,
            }
        )

    async def chat_message(self, event):
        await self.send(text_data=event["message"])

    @database_sync_to_async
    def is_user_allowed(self, user, room_name):
        # Replace this with your actual logic (e.g., DB check)
        # For example:
        # return Interview.objects.filter(room_id=room_name, users__in=[user]).exists()
        allowed_rooms = {
            "room1": ["interviewer@example.com", "candidate@example.com"],
        }
        return user.email in allowed_rooms.get(room_name, [])