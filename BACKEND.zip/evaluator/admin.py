from django.contrib import admin
from .models import Candidate, Interview, InterviewRound

admin.site.register(Candidate)
admin.site.register(Interview)
admin.site.register(InterviewRound)
