import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class CodeService {
  private apiUrl = "http://localhost:8000/api";

  constructor(private http: HttpClient) {}

  fetchCodingQuestion({
    type = "technical",
    topic = "recursion",
    difficulty = "medium",
    language,
  }: {
    type?: string;
    topic?: string;
    difficulty?: string;
    language: string;
  }): Observable<any> {
    return this.http.get<{ question: string; }>(
      `${this.apiUrl}/question/?type=${type}&topic=${topic}&difficulty=${difficulty}&language=${language}`
    );
  }

  submitCode(data: {
    code: any;
    language: string;
    question: string;
    test_cases: any;
  }): Observable<any> {
    return this.http.post<{
      aiEvaluation: string;
      testResults: {
        input: string;
        expected: string;
        actual: string;
        passed: boolean;
      }[];
    }>(`${this.apiUrl}/evaluate-code/`, data);
  }

  runCode(data: { code: any; language: string; input: any }): Observable<any> {
    return this.http.post<{
      output: { exit_code: number; stderr: string; stdout: string };
    }>(`${this.apiUrl}/run-code/`, data);
  }

  generateTestCases(data: {
    language: string;
    question: string;
  }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/test-cases/`, data);
  }
}
