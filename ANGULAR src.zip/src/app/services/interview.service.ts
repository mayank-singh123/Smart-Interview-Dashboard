import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({ providedIn: "root" })
export class InterviewService {
  private baseUrl = "http://localhost:8000/api/ai-interview";

  constructor(private http: HttpClient) {}

  getQuestion() {
    return this.http.get<{ question: string }>(`${this.baseUrl}/question/`);
  }

  evaluateAnswer(formData: FormData) {
    return this.http.post<{
      question: string;
      transcription: string;
      expected_answer: string;
      correctness_score: number;
      completeness_score: number;
      score: number;
    }>(`${this.baseUrl}/evaluate/`, formData);
  }
}
