import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class MonitorService {
  private apiUrl = "http://localhost:8000/api";

  constructor(private http: HttpClient) {}

  detectFace(data: FormData): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/detect-face/`, data);
  }

  submitAudio(data: FormData): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/submit-audio/`, data);
  }

  uploadScreen(data: FormData): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/upload-screen/`, data);
  }
}
