import { Component, ViewChild, ElementRef, OnDestroy } from "@angular/core";
import { CommonModule } from "@angular/common";
// import { HttpClientModule } from "@angular/common/http";
import { InterviewService } from "../../services/interview.service";

declare var Recorder: any;

@Component({
  selector: "app-interview-ai",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./interview-ai.component.html",
  styleUrls: ["./interview-ai.component.css"],
  providers: [InterviewService],
})
export class InterviewAiComponent implements OnDestroy {
  @ViewChild("videoElement") videoElement!: ElementRef;

  userName: string = "Candidate Name";
  question = "";
  feedback = "";
  transcript = "";
  questionCount = 0;
  maxQuestions = 10;
  totalQuestions: number = this.maxQuestions;
  feedbackTags: string[] = [
    "Clear Communication",
    "Confident",
    "Well Structured",
  ];
  questionList = Array.from({ length: this.maxQuestions });

  recording: boolean = false;
  interview: boolean = true;
  mediaRecorder: any;
  audioChunks: any[] = [];
  stream: MediaStream | null = null;
  timer: number = 5;
  intervalId: any;

  recorder: any;
  audioContext: AudioContext | null = null;

  scores: number[] = [];

  constructor(private interviewService: InterviewService) {}

  async startInterview() {
    this.interview = false;
    this.questionCount = 0;
    await this.setupCamera();
    this.nextQuestion();
  }

  async setupCamera() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      if (this.videoElement) {
        this.videoElement.nativeElement.srcObject = this.stream;
        this.videoElement.nativeElement.muted = true;
      }
    } catch (err) {
      console.error("Camera/mic access denied:", err);
    }
  }

  nextQuestion() {
    if (this.questionCount >= this.maxQuestions) {
      this.feedback = "✅ Interview completed!";
      this.cleanupMedia();
      return;
    }

    this.questionCount++;
    this.feedback = "";
    this.transcript = "";

    this.timer = 5;

    this.interviewService.getQuestion().subscribe({
      next: (res) => {
        this.question = res.question;
        this.startTimer(true);
      },
      error: (err) => {
        this.feedback = "❌ Failed to load question.";
        console.error(err);
      },
    });
  }

  async startRecording() {
    if (!this.stream) return;

    this.recording = true;
    this.timer = 10;

    this.audioContext = new AudioContext();
    const input = this.audioContext.createMediaStreamSource(this.stream);
    this.recorder = new Recorder(input, { numChannels: 1 });

    this.recorder.record();
    this.startTimer();
  }

  async stopRecording() {
    this.recording = false;
    clearInterval(this.intervalId);

    this.recorder.stop();

    this.nextQuestion();

    this.recorder.exportWAV((blob: Blob) => {
      const formData = new FormData();
      formData.append("question", this.question);
      formData.append("audio", blob, "answer.wav");

      this.interviewService.evaluateAnswer(formData).subscribe({
        next: (res) => {
          console.log(res);
          this.scores.push(res.score);
          // this.feedback = res.feedback;
          // this.transcript = res.transcript;

          // Automatically move to next question after 3 seconds
          // setTimeout(() => this.nextQuestion(), 3000);
        },
        error: (err) => {
          this.feedback = "❌ Failed to evaluate answer.";
          console.error(err);
        },
      });
    });
  }

  startTimer(isPreRecordingPhase: boolean = false) {
    const tick = () => {
      if (this.timer > 0) {
        this.timer--;
        this.intervalId = setTimeout(tick, 1000);
      } else {
        if (isPreRecordingPhase) {
          this.startRecording();
        } else {
          this.stopRecording();
        }
      }
    };

    clearTimeout(this.intervalId);
    tick();
  }

  downloadTranscript() {
    const blob = new Blob([this.transcript || ""], { type: "application/pdf" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `interview-transcript-${this.userName.replace(
      /\s+/g,
      "_"
    )}.pdf`;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  cleanupMedia() {
    this.scores = [];
    this.question = "";
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
  }

  ngOnDestroy() {
    this.cleanupMedia();
  }
}
