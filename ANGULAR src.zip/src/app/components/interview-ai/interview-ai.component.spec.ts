import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewAiComponent } from './interview-ai.component';

describe('InterviewAiComponent', () => {
  let component: InterviewAiComponent;
  let fixture: ComponentFixture<InterviewAiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InterviewAiComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InterviewAiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
