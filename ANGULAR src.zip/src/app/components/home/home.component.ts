import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  HostListener,
  Inject,
} from "@angular/core";
// import 'flowbite';
import { trigger, style, animate, transition } from "@angular/animations";
import { CommonModule } from "@angular/common";

import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
} from "@angular/material/dialog";
import { MatButtonModule } from "@angular/material/button";

@Component({
  selector: "app-home",
  standalone: true,
  imports: [CommonModule, MatButtonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: "./home.component.html",
  styleUrl: "./home.component.css",
  animations: [
    trigger("fadeInUp", [
      transition(":enter", [
        style({ opacity: 0, transform: "translateY(30px)" }),
        animate(
          "800ms ease-out",
          style({ opacity: 1, transform: "translateY(0)" })
        ),
      ]),
    ]),
  ],
})
export class HomeComponent {
  currentYear: number = new Date().getFullYear();
  showModal: boolean = false;

  constructor(private dialog: MatDialog) {}

  openModal() {
    this.dialog.open(HomeModalComponent);
  }

  isVisible = false;

  @HostListener("window:scroll", [])
  onScroll(): void {
    const section = document.getElementById("about-section");
    if (section) {
      const rect = section.getBoundingClientRect();
      this.isVisible = rect.top < window.innerHeight * 0.75;
    }
  }

  products = [
    {
      name: "Rose Elegance",
      image: "/assets/images/product1.jpg",
      description: "A classic red rose bouquet.",
    },
    {
      name: "Tulip Whisper",
      image: "/assets/images/product2.jpg",
      description: "Soft tulips for gentle moments.",
    },
    {
      name: "Orchid Grace",
      image: "/assets/images/product3.jpg",
      description: "Elegant orchids in bloom.",
    },
  ];

  openProduct(product: any) {
    this.dialog.open(ProductModalComponent, {
      data: product,
      panelClass: "product-modal",
    });
  }

  images = [
    "./assets/images/gallery1.jpg",
    "/assets/images/gallery2.jpg",
    "/assets/images/gallery3.jpg",
    "/assets/images/gallery4.jpg",
    "/assets/images/gallery5.jpg",
    "/assets/images/gallery6.jpg",
  ];

  openLightbox(image: string) {
    this.dialog.open(GalleryLightboxComponent, {
      data: { image },
      panelClass: "gallery-lightbox",
    });
  }
}

@Component({
  selector: "app-home-modal",
  standalone: true,
  template: `<div class="p-6 text-center">Welcome to Flowerbite 🌸</div>`,
})
export class HomeModalComponent {}

@Component({
  selector: "app-product-modal",
  standalone: true,
  imports: [CommonModule, MatDialogModule],
  template: `
    <div class="p-6 text-center">
      <img
        [src]="data.image"
        alt="{{ data.name }}"
        class="w-full h-64 object-cover rounded mb-4"
      />
      <h2 class="text-2xl font-bold mb-2">{{ data.name }}</h2>
      <p class="text-gray-700">{{ data.description }}</p>
    </div>
  `,
})
export class ProductModalComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}
}

@Component({
  selector: "app-gallery-lightbox",
  standalone: true,
  imports: [CommonModule, MatDialogModule],
  template: `
    <div
      class="p-4 flex justify-center items-center bg-black bg-opacity-90 h-full"
    >
      <img
        [src]="data.image"
        alt="Preview"
        class="max-h-[90vh] rounded-lg shadow-lg"
      />
    </div>
  `,
})
export class GalleryLightboxComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: { image: string }) {}
}
