import {
  // AfterViewInit,
  Component,
  ElementRef,
  ViewChild,
  signal,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { MarkdownModule } from "ngx-markdown";
import { FormsModule } from "@angular/forms";
import { MatCardModule } from "@angular/material/card";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatButtonModule } from "@angular/material/button";
import { MatSelectModule } from "@angular/material/select";
import { MatInputModule } from "@angular/material/input";
import { CodeService } from "../../services/code.service";

import { EditorComponent } from 'ngx-monaco-editor-v2';

declare const monaco: any;

@Component({
  selector: "app-code-editor",
  imports: [
    CommonModule,
    MarkdownModule,
    FormsModule,
    MatCardModule,
    MatSelectModule,
    MatFormFieldModule,
    MatButtonModule,
    MatInputModule,
    EditorComponent
  ],
  templateUrl: "./code-editor.component.html",
  styleUrl: "./code-editor.component.css",
})
export class CodeEditorComponent {
  @ViewChild("editorContainer", { static: true }) editorContainer!: ElementRef;
  public selectedLanguage: string = "javascript";
  private editorInstance: any;
  // private boilerplateLineCount = 0;

  question = signal("");
  test_cases: string = "";
  feedback = signal("");

  output: string = "";
  customInput: string = "";

  testResults: {
    input: string;
    expected: string;
    actual: string;
    passed: boolean;
  }[] = [];

  isResizing = false;

  editorOptions: any = {};
  editorCode = "";

  // private boilerplate = "";
  // private boilerplateLines = 0;

  // private languageUserCodeMap: Record<string, string> = {};

  constructor(private codeService: CodeService) {}

  boilerplates: { [key: string]: string } = {
    python: `# DO NOT MODIFY BELOW THIS LINE
def helper():
    return "Helper function"

if __name__ == "__main__":
   _input = input()
    # WRITE YOUR CODE BELOW THIS LINE
`,
    javascript: `// DO NOT MODIFY BELOW THIS LINE
function helper() {
    return "Helper function";
}

const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('', function(user_input) {
    // WRITE YOUR CODE BELOW THIS LINE
`,
    java: `// DO NOT MODIFY BELOW THIS LINE
import java.util.Scanner;

public class Main {
    String helper() {
        return "Helper function";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String user_input = scanner.nextLine();
        // WRITE YOUR CODE BELOW THIS LINE
`,
    cpp: `// DO NOT MODIFY BELOW THIS LINE
#include <iostream>
#include <string>
using namespace std;

string helper() {
    return "Helper function";
}

int main() {
    string user_input;
    getline(cin, user_input);
    // WRITE YOUR CODE BELOW THIS LINE
`,
  };

  ngOnInit() {
    this.setLanguage(this.selectedLanguage);
  }

  setLanguage(lang: string) {
    this.selectedLanguage = lang;
    this.editorCode = this.boilerplates[lang];
    this.editorOptions = {
      theme: "vs-dark",
      language: lang === "cpp" ? "cpp" : lang,
      readOnly: false,
      automaticLayout: true,
    };
  }

  onEditorInit(editor: any) {
    this.editorInstance = editor;
    const boilerplateLines =
      this.boilerplates[this.selectedLanguage].split("\n").length;

    editor.onDidChangeModelContent((e: any) => {
      const model = editor.getModel();
      const edits = e.changes;

      for (const change of edits) {
        if (change.range.startLineNumber <= boilerplateLines) {
          // Undo the change if it's in the read-only region
          editor.executeEdits("", [
            {
              range: change.range,
              text: "",
              forceMoveMarkers: true,
            },
          ]);
        }
      }
    });
  }

  startResizing(event: MouseEvent) {
    this.isResizing = true;
    const startX = event.clientX;
    const leftPane = document.querySelector(".left-pane") as HTMLElement;
    const rightPane = document.querySelector(".right-pane") as HTMLElement;
    const initialLeftWidth = leftPane.getBoundingClientRect().width;

    const onMouseMove = (e: MouseEvent) => {
      if (!this.isResizing) return;
      const delta = e.clientX - startX;
      const newLeftWidth = Math.min(
        Math.max(initialLeftWidth + delta, 300),
        window.innerWidth - 300
      );
      leftPane.style.flex = `0 0 ${newLeftWidth}px`;
      rightPane.style.flex = `1 1 auto`;
      if (this.editorInstance) {
        this.editorInstance.layout();
      }
    };

    const onMouseUp = () => {
      this.isResizing = false;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };

    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  }

  generateTestCases() {
    this.codeService
      .generateTestCases({
        question: this.question(),
        language: this.selectedLanguage,
      })
      .subscribe({
        next: (res) => {
          console.log(res);
          this.test_cases = res;
          // this.test_cases = res.test_cases;
        },
        error: (err) => {
          console.log(err);
          this.question.set("Failed to load question.");
        },
      });
  }

  fetchQuestion({
    type = "technical",
    topic = "recursion",
    difficulty = "medium",
    language,
  }: {
    type?: string;
    topic?: string;
    difficulty?: string;
    language: string;
  }) {
    this.codeService
      .fetchCodingQuestion({ type, topic, difficulty, language })
      .subscribe({
        next: (res) => {
          console.log(res);
          this.question.set(res.question);
          // this.test_cases = res.test_cases;
        },
        error: (err) => {
          console.log(err);
          this.question.set("Failed to load question.");
        },
      });
  }

  submitCode() {
    this.codeService
      .submitCode({
        code: this.editorInstance.getValue(),
        language: this.selectedLanguage,
        // input: this.customInput,
        question: this.question(),
        test_cases: this.test_cases,
      })
      .subscribe({
        next: (res) => {
          console.log(res);
          this.feedback.set(res.aiEvaluation);
          // this.testResults = res.testResults;
        },
        error: (err) => this.feedback.set("Failed to submit code."),
      });
  }

  runCode() {
    this.codeService
      .runCode({
        code: this.editorInstance.getValue(),
        language: this.selectedLanguage,
        input: this.customInput,
      })
      .subscribe({
        next: (res) => {
          console.log(res);
          this.output =
            res.output.stderr?.length > 0
              ? res.output.stderr
              : res.output.stdout;
        },
        error: (err) => this.feedback.set("Failed to run code."),
      });
  }
}
