import { Component } from "@angular/core";
import { MonitorService } from "../../../services/monitor.service";

@Component({
  selector: "app-screen",
  imports: [],
  templateUrl: "./screen.component.html",
  styleUrl: "./screen.component.css",
})
export class ScreenComponent {
  private mediaRecorder!: MediaRecorder;
  private recordedChunks: Blob[] = [];
  isRecording = false;

  constructor(private monitorService: MonitorService) {}

  async startScreenRecording() {
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true, // Some browsers support audio too
      });

      this.recordedChunks = [];
      this.mediaRecorder = new MediaRecorder(displayStream, {
        mimeType: "video/webm",
      });
      this.mediaRecorder.start();
      this.isRecording = true;

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) this.recordedChunks.push(event.data);
      };

      this.mediaRecorder.onstop = () => {
        const screenBlob = new Blob(this.recordedChunks, {
          type: "video/webm",
        });
        const formData = new FormData();
        formData.append("screen", screenBlob, "screen-recording.webm");

        this.monitorService.uploadScreen(formData).subscribe({
          next: (res) => {
            console.log("Screen upload response:", res);
          },
          error: (err) => {
            console.log(err);
          },
        });
      };
    } catch (err) {
      console.error("Error accessing screen:", err);
    }
  }

  stopScreenRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop();
      this.isRecording = false;
    }
  }
}
