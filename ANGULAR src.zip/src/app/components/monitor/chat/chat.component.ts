import { CommonModule } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { Peer, DataConnection, MediaConnection } from "peerjs";

@Component({
  selector: "app-chat",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./chat.component.html",
  styleUrl: "./chat.component.css",
})
export class ChatComponent implements OnInit {
  peer: Peer | null = null;
  conn: DataConnection | null = null;
  ws: WebSocket | null = null;
  localStream: MediaStream | null = null;
  remoteStream: MediaStream | null = null;
  messages: string[] = [];
  chatInput = "";

  ngOnInit(): void {
    this.initializeWebSocket();
    this.initPeer();
    // this.startLocalVideo();
  }

  initializeWebSocket(): void {
    if (typeof window === "undefined") {
      console.warn("Running on server; skipping WebSocket init");
      return;
    }

    const room = "room1"; // Replace with dynamic room id
    const token = localStorage.getItem("token");
    if (!token) {
      console.error("Auth token not found, cannot connect to WebSocket");
      return;
    }

    this.ws = new WebSocket(
      `ws://localhost:8000/ws/interview/${room}/?token=${token}`
    );

    this.ws.onmessage = (event: MessageEvent) => {
      const data = JSON.parse(event.data);
      if (data.type === "chat") {
        this.messages.push(data.message);
      }
    };

    this.ws.onclose = () => {
      console.log("WebSocket connection closed");
    };
  }

  sendMessage(): void {
    // if (this.ws) {
    //   this.ws.send(JSON.stringify({ type: "chat", message: this.chatInput }));
    //   this.chatInput = "";
    // }

    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn("WebSocket is not open. Cannot send message.");
      return;
    }

    const message = {
      sender: "candidate@example.com", // this.userName
      message: this.chatInput,
      type: "chat",
    };

    this.ws.send(JSON.stringify(message));
    this.chatInput = "";
  }

  initPeer(): void {
    this.peer = new Peer();

    this.peer.on("open", (id: string) => {
      console.log("My peer ID is: " + id);
    });

    this.peer.on("call", (call: MediaConnection) => {
      if (this.localStream) {
        call.answer(this.localStream);
        call.on("stream", (remoteStream: MediaStream) => {
          this.remoteStream = remoteStream;
          this.attachRemoteStream(remoteStream);
        });
      }
    });

    this.peer.on("connection", (conn: DataConnection) => {
      this.conn = conn;
      conn.on("data", (data: unknown) => {
        if (typeof data === "string") {
          this.messages.push(data);
        }
      });
    });
  }

  // startLocalVideo(): void {
  //   navigator.mediaDevices
  //     .getUserMedia({ video: true, audio: true })
  //     .then((stream: MediaStream) => {
  //       this.localStream = stream;
  //       const video = document.querySelector("#local-video") as HTMLVideoElement;
  //       if (video) {
  //         video.srcObject = stream;
  //         video.play();
  //       }
  //     })
  //     .catch((error) => {
  //       console.error("Error accessing media devices.", error);
  //     });
  // }

  attachRemoteStream(stream: MediaStream): void {
    const remoteVideo = document.querySelector(
      "#remote-video"
    ) as HTMLVideoElement;
    if (remoteVideo) {
      remoteVideo.srcObject = stream;
      remoteVideo.play();
    }
  }

  callPeer(remotePeerId: string): void {
    if (!this.peer || !this.localStream) return;

    const call = this.peer.call(remotePeerId, this.localStream);
    call.on("stream", (remoteStream: MediaStream) => {
      this.attachRemoteStream(remoteStream);
    });
  }

  // shareScreen(): void {
  //   navigator.mediaDevices
  //     .getDisplayMedia({ video: true })
  //     .then((screenStream: MediaStream) => {
  //       const videoTrack = screenStream.getVideoTracks()[0];

  //       // Replace local video
  //       const localVideo = document.querySelector("#local-video") as HTMLVideoElement;
  //       if (localVideo) {
  //         localVideo.srcObject = screenStream;
  //         localVideo.play();
  //       }

  //       if (this.peer) {
  //         const peerConnections = this.peer["connections"] as Record<string, DataConnection[]>;
  //         const connectionIds = Object.keys(peerConnections);
  //         if (connectionIds.length > 0) {
  //           const firstConnection = peerConnections[connectionIds[0]][0];
  //           const sender = firstConnection.peerConnection
  //             .getSenders()
  //             .find((s) => s.track?.kind === "video");

  //           if (sender) {
  //             sender.replaceTrack(videoTrack);
  //           }
  //         }
  //       }
  //     })
  //     .catch((error) => {
  //       console.error("Error sharing screen:", error);
  //     });
  // }
}
