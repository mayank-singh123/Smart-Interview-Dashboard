import { Component } from "@angular/core";
import { CameraComponent } from "../camera/camera.component";
import { MicComponent } from "../mic/mic.component";
import { ScreenComponent } from "../screen/screen.component";
import { ChatComponent } from "../chat/chat.component";

@Component({
  selector: "app-interview",
  imports: [CameraComponent, MicComponent, ScreenComponent, ChatComponent],
  templateUrl: "./interview.component.html",
  styleUrl: "./interview.component.css",
})
export class InterviewComponent {}
