import { Component, ElementRef, ViewChild } from "@angular/core";
import { MonitorService } from "../../../services/monitor.service";

@Component({
  selector: "app-camera",
  imports: [],
  templateUrl: "./camera.component.html",
  styleUrl: "./camera.component.css",
})
export class CameraComponent {
  @ViewChild("video") videoRef!: ElementRef;
  @ViewChild("canvas") canvasRef!: ElementRef;

  constructor(
    private monitorService: MonitorService
  ) {}

  ngAfterViewInit() {
    // navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
    //   this.videoRef.nativeElement.srcObject = stream;
    // });

    if (typeof navigator !== "undefined" && navigator.mediaDevices) {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          this.videoRef.nativeElement.srcObject = stream;
        })
        .catch((error) => {
          console.error("Media error:", error);
        });
    } else {
      console.warn("Media devices not available in this environment.");
    }
  }

  capture() {
    const video = this.videoRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob: any) => {
      const formData = new FormData();
      formData.append("image", blob);

      this.monitorService.detectFace(formData).subscribe({
        next: (res) => {
          console.log(res);
        },
        error: (err) => {
          console.log(err);
        },
      });
    }, "image/jpeg");
  }
}
