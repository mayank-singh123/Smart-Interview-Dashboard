import { CommonModule } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";

type OptionKey = "A" | "B" | "C" | "D";

interface Question {
  id: number;
  question: string;
  options: Record<OptionKey, string>;
  correct_answer: OptionKey;
  userAnswer?: OptionKey;
}

@Component({
  selector: "app-mcqs",
  imports: [CommonModule, FormsModule],
  templateUrl: "./mcqs.component.html",
  styleUrl: "./mcqs.component.css",
})
export class McqsComponent implements OnInit {
  questions: Question[] = [];
  score: number | null = null;
  optionKeys: OptionKey[] = ["A", "B", "C", "D"];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http
      .get<Question[]>(
        "http://localhost:8000/api/mcq?technology=javascript&difficulty=medium"
      )
      .subscribe((data) => {
        console.log(data);
        this.questions = data;
      });
  }

  submitAnswers() {
    let score = 0;
    this.questions.forEach((q) => {
      console.log(q.userAnswer, q.correct_answer);
      if (q?.userAnswer === q?.correct_answer) {
        score++;
      }
    });
    this.score = score;
  }
}
