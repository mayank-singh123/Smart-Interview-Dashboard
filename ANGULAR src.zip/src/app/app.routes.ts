import { Routes } from "@angular/router";
import { LoginComponent } from "./auth/login/login.component";
import { RegisterComponent } from "./auth/register/register.component";
import { AdminDashboardComponent } from "./dashboard/admin/admin.component";
import { AuthGuard } from "./auth/auth.guard";

export const routes: Routes = [
  { path: "", redirectTo: "home", pathMatch: "full" },
  {
    path: "home",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./components/home/home.component").then((m) => m.HomeComponent),
  },
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },

  {
    path: "mcq",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./components/mcqs/mcqs.component").then((m) => m.McqsComponent),
  },
  {
    path: "code",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./components/code-editor/code-editor.component").then(
        (m) => m.CodeEditorComponent
      ),
  },
  {
    path: "interview-ai",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./components/interview-ai/interview-ai.component").then(
        (m) => m.InterviewAiComponent
      ),
  },
  {
    path: "interview",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./components/monitor/interview/interview.component").then(
        (m) => m.InterviewComponent
      ),
  },
  {
    path: "interviewer",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./dashboard/interviewer/interviewer.component").then(
        (m) => m.InterviewerDashboardComponent
      ),
  },
  {
    path: "evaluation",
    canActivate: [AuthGuard],
    loadComponent: () =>
      import("./dashboard/candidate/candidate.component").then(
        (m) => m.CandidateDashboardComponent
      ),
  },

  { path: "admin", component: AdminDashboardComponent },

  { path: "**", redirectTo: "home" },
];
