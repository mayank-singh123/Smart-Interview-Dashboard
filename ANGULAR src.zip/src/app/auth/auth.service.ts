import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";

@Injectable({ providedIn: "root" })
export class AuthService {
  private apiUrl = "http://localhost:8000/api";

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: { email: string; password: string }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login/`, credentials).pipe(
      tap((response) => {
        localStorage.setItem("token", response.access);
        const role = this.getRoleFromToken(response.access);
        this.redirectBasedOnRole(role);
      })
    );
  }

  register(data: {
    username: string;
    email: string;
    password: string;
    role: string;
  }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/register/`, data, {
      headers: { "Content-Type": "application/json" },
    });
  }

  logout(): void {
    localStorage.removeItem("token");
    this.router.navigate(["/login"]);
  }

  isAuthenticated(): boolean {
    const token = localStorage.getItem("token");
    if (!token) return false;

    const payload = JSON.parse(atob(token.split(".")[1]));
    const now = Math.floor(new Date().getTime() / 1000);
    return payload.exp > now;
  }

  getUserRole(): string | null {
    const token = localStorage.getItem("token");
    if (!token) return null;

    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.role;
  }

  private getRoleFromToken(token: string): string {
    const payload = JSON.parse(atob(token.split(".")[1]));
    console.log(payload);
    return payload.role;
  }

  private redirectBasedOnRole(role: string): void {
    if (role === "admin") {
      this.router.navigate(["/admin"]);
    } else if (role === "interviewer") {
      this.router.navigate(["/interviewer"]);
    } else if (role === "candidate") {
      this.router.navigate(["/evaluation"]);
    }
  }
}
