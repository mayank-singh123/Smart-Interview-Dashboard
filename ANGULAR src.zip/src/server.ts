import express, { Request, Response } from 'express';
import cors from 'cors';
import multer from 'multer';
import bodyParser from 'body-parser';
import axios from 'axios';
import FormData from 'form-data';
import dotenv from 'dotenv';
import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// Load environment variables
dotenv.config();

// Setup paths
const serverDistFolder = dirname(fileURLToPath(import.meta.url));
const browserDistFolder = resolve(serverDistFolder, '../browser');

// Create Express app
const app = express();
const angularApp = new AngularNodeAppEngine();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Multer setup for audio upload
const upload = multer({ storage: multer.memoryStorage() });

// ✅ API: Get a random interview question
app.get('/question', (req: Request, res: Response) => {
  const questions = [
    "Tell me about yourself.",
    "What are your strengths?",
    "Why should we hire you?",
    "Describe a challenge you faced and how you overcame it."
  ];
  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  res.json({ question: randomQuestion });
});

// 🔁 Helper: Transcribe audio using OpenAI Whisper
async function transcribeAudio(audioBuffer: Buffer): Promise<string> {
  const formData = new FormData();
  formData.append('file', audioBuffer, 'audio.webm');
  formData.append('model', 'whisper-1');

  const response = await axios.post('https://api.openai.com/v1/audio/transcriptions', formData, {
    headers: {
      ...formData.getHeaders(),
      Authorization: `Bearer ${process.env['OPENAI_API_KEY']}`,
    },
  });

  return response.data.text;
}

// 🔁 Helper: Evaluate answer using GPT-4
async function evaluateAnswer(question: string, answer: string): Promise<string> {
  const prompt = `You are an AI interviewer. Evaluate the following answer to the question.\n\nQuestion: ${question}\nAnswer: ${answer}\n\nGive constructive feedback:`;

  const response = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
  }, {
    headers: {
      Authorization: `Bearer ${process.env['OPENAI_API_KEY']}`,
    },
  });

  return response.data.choices[0].message.content;
}

// ✅ API: Receive audio and return feedback
app.post('/answer', upload.single('audio'), async (req: Request, res: Response) => {
  try {
    const file = req.file;
    const question = req.body.question;

    if (!file || !question) {
      return res.status(400).json({ error: 'Missing audio or question' });
    }

    const transcript = await transcribeAudio(file.buffer);
    const feedback = await evaluateAnswer(question, transcript);

    return res.json({ feedback, transcript });

  } catch (error) {
    console.error('Error processing answer:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Serve static files
app.use(express.static(browserDistFolder, {
  maxAge: '1y',
  index: false,
  redirect: false,
}));

// Angular SSR handler
app.use('/**', (req, res, next) => {
  angularApp
    .handle(req)
    .then((response) => {
      if (response) {
        writeResponseToNodeResponse(response, res);
      } else {
        next();
      }
    })
    .catch(next);
});

// Start server
if (isMainModule(import.meta.url)) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, () => {
    console.log(`✅ Node Express server listening on http://localhost:${port}`);
  });
}

// Export handler for SSR
export const reqHandler = createNodeRequestHandler(app);
